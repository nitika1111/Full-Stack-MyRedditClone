package com.nitika.myredditapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyredditappApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyredditappApplication.class, args);
	}

}
